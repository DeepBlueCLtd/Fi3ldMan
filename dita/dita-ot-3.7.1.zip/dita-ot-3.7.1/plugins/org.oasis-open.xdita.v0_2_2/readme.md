# XDITA grammar files

These are pre-release grammar files for XDITA -the XML-based authoring format of Lightweight DITA. 
