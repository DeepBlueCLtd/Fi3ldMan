# Cross-format Content with Lightweight DITA (LwDITA draft as of 2018-10-29)


**Experimental LwDITA authoring modes included. Not all topics and elements are functional in actual LwDITA transformations**
