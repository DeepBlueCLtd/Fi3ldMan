# DITA 2.0 Technical Communications grammar files

Early draft of DITA 2.0 compatible DITA for technical communications doctypes,
such as concept, task, and reference. Early draft, not for production use,
probably not even valid yet.